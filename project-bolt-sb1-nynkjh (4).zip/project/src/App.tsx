import React from 'react';
import { DollarSign, Plane, Ship, Car } from 'lucide-react';
import ProfileCard from './components/ProfileCard';
import POAPBadge from './components/POAPBadge';
import ServiceCard from './components/ServiceCard';
import Footer from './components/Footer';
import CountUp from './components/CountUp';
import FlightHistory from './components/FlightHistory';
import DiscountBanner from './components/DiscountBanner';

function App() {
  const flightHistory = [
    {
      from: 'Paris',
      to: 'Dubai',
      date: 'Mar 15, 2024',
      class: 'first' as const,
    },
    {
      from: 'London',
      to: 'New York',
      date: 'Feb 28, 2024',
      class: 'business' as const,
    },
    {
      from: 'Singapore',
      to: 'Tokyo',
      date: 'Jan 12, 2024',
      class: 'first' as const,
    },
  ];

  return (
    <div className="min-h-screen bg-gradient-to-br from-[#0A0A0A] to-[#1A1A1A] relative">
      <div className="absolute inset-0 z-0">
        <img
          src="https://images.unsplash.com/photo-1540962351504-03099e0a754b?auto=format&fit=crop&q=80&w=2070&h=1380"
          alt="Private Jet Background"
          className="w-full h-full object-cover opacity-5"
        />
      </div>
      <div className="relative z-10">
        <nav className="border-b border-white/10 backdrop-blur-lg bg-black/30">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="flex items-center justify-between h-16">
              <div className="flex items-center">
                <img 
                  src="https://cdn.prod.website-files.com/64d27300a79f21c59b1ccba5/64d28def4c01e9845a8eb798_IconConcierge.svg"
                  alt="Logo"
                  className="h-8"
                />
              </div>
              <div className="flex items-center space-x-4">
                <button className="px-4 py-2 rounded-lg bg-gold text-black font-semibold hover:bg-gold/90 transition-colors">
                  Connect Wallet
                </button>
              </div>
            </div>
          </div>
        </nav>

        <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-24">
          <div className="flex flex-col items-center mb-16" data-aos="zoom-in" data-aos-duration="1500">
            <POAPBadge />
          </div>

          <div className="text-center mb-12" data-aos="fade-up">
            <h1 className="text-4xl font-bold text-gold mb-4 tracking-tight">
              Digital passport to luxury travel
            </h1>
            <p className="text-white/60 max-w-2xl mx-auto">
              Exclusive Member Profile. Showcase your journey with exclusive POAPs
              and track your elite status.
            </p>
          </div>

          <DiscountBanner />

          <div className="max-w-2xl mx-auto mb-24">
            <ProfileCard
              instagramHandle="luxurytraveler"
              profileImage="https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&q=80&w=300&h=300"
              businessFlights={24}
              firstClassFlights={12}
              maybachTransfers={18}
              flightHistory={flightHistory}
            />
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mb-24">
            <ServiceCard
              title="LUXURY CARS"
              description="Experience unparalleled comfort with our premium fleet of luxury vehicles."
              image="https://images.unsplash.com/photo-1549399542-7e3f8b79c341"
              icon={<Car className="w-8 h-8 text-white" />}
            />
            <ServiceCard
              title="FLIGHTS"
              description="First-class and private jet experiences to your dream destinations."
              image="https://images.unsplash.com/photo-1436491865332-7a61a109cc05"
              icon={<Plane className="w-8 h-8 text-white" />}
            />
            <ServiceCard
              title="YACHTS"
              description="Luxury yacht charters for unforgettable maritime adventures."
              image="https://images.unsplash.com/photo-1567899378494-47b22a2ae96a"
              icon={<Ship className="w-8 h-8 text-white" />}
            />
          </div>
        </main>

        <Footer />
      </div>
    </div>
  );
}

export default App;