import React from 'react';
import { Plane } from 'lucide-react';

interface Flight {
  from: string;
  to: string;
  date: string;
  class: 'business' | 'first';
}

interface FlightHistoryProps {
  flight: Flight;
  index: number;
}

export default function FlightHistory({ flight, index }: FlightHistoryProps) {
  return (
    <div 
      className="relative"
      data-aos="fade-up"
      data-aos-delay={200 * (index + 1)}
    >
      <div className="flex items-center justify-between">
        <div className="w-1/3 text-right">
          <h4 className="text-white font-medium">{flight.from}</h4>
          <p className="text-gold/60 text-sm">{flight.date}</p>
        </div>
        
        <div className="w-1/3 relative px-4">
          <div className="h-[2px] bg-gradient-to-r from-transparent via-gold to-transparent" />
          <div className="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2">
            <div className="relative">
              <div className="absolute inset-0 bg-gold/20 rounded-full animate-ping" />
              <Plane className="w-6 h-6 text-gold transform -rotate-45" />
            </div>
          </div>
        </div>

        <div className="w-1/3 text-left">
          <h4 className="text-white font-medium">{flight.to}</h4>
          <p className="text-gold/60 text-sm capitalize">{flight.class} Class</p>
        </div>
      </div>
    </div>
  );
}