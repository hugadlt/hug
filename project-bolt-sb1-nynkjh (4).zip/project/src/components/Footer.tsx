import React from 'react';
import { Instagram, Twitter, Facebook, Mail } from 'lucide-react';

export default function Footer() {
  return (
    <footer className="bg-black/40 border-t border-white/10">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
          <div>
            <h4 className="text-gold font-semibold mb-4">About Us</h4>
            <p className="text-white/60">
              Experience luxury travel like never before with our exclusive concierge services.
            </p>
          </div>
          
          <div>
            <h4 className="text-gold font-semibold mb-4">Services</h4>
            <ul className="space-y-2 text-white/60">
              <li>Private Jets</li>
              <li>Luxury Cars</li>
              <li>Yacht Charters</li>
              <li>VIP Concierge</li>
            </ul>
          </div>
          
          <div>
            <h4 className="text-gold font-semibold mb-4">Contact</h4>
            <ul className="space-y-2 text-white/60">
              <li>+1 (888) 123-4567</li>
              <li>contact@luxurytravel.com</li>
              <li>24/7 Support</li>
            </ul>
          </div>
          
          <div>
            <h4 className="text-gold font-semibold mb-4">Follow Us</h4>
            <div className="flex space-x-4">
              <a href="#" className="text-white/60 hover:text-gold transition-colors">
                <Instagram className="w-6 h-6" />
              </a>
              <a href="#" className="text-white/60 hover:text-gold transition-colors">
                <Twitter className="w-6 h-6" />
              </a>
              <a href="#" className="text-white/60 hover:text-gold transition-colors">
                <Facebook className="w-6 h-6" />
              </a>
              <a href="#" className="text-white/60 hover:text-gold transition-colors">
                <Mail className="w-6 h-6" />
              </a>
            </div>
          </div>
        </div>
        
        <div className="mt-12 pt-8 border-t border-white/10 text-center text-white/40">
          <p>© 2024 Luxury Travel. All rights reserved.</p>
        </div>
      </div>
    </footer>
  );
}