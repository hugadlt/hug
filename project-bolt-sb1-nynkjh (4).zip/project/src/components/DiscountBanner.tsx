import React from 'react';
import { DollarSign, Sparkles } from 'lucide-react';

export default function DiscountBanner() {
  return (
    <div className="max-w-2xl mx-auto mb-12" data-aos="fade-up" data-aos-delay="400">
      <div className="relative overflow-hidden rounded-xl bg-gradient-to-r from-gold/20 via-gold/10 to-transparent p-1">
        <div className="absolute inset-0 bg-gradient-to-r from-gold/20 to-transparent animate-pulse" />
        <div className="relative bg-black/40 rounded-lg p-6">
          <div className="flex items-center gap-4">
            <div className="relative">
              <DollarSign className="w-10 h-10 text-gold" />
              <Sparkles className="absolute -top-2 -right-2 w-6 h-6 text-gold animate-pulse" />
            </div>
            <div>
              <h3 className="text-xl md:text-2xl font-bold text-white">
                Your Luxury Flights up to 70% OFF
              </h3>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}