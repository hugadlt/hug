import React from 'react';
import { LucideIcon } from 'lucide-react';

interface ServiceCardProps {
  title: string;
  description: string;
  image: string;
  icon: React.ReactNode;
}

export default function ServiceCard({ title, description, image, icon }: ServiceCardProps) {
  return (
    <div 
      className="group relative overflow-hidden rounded-xl"
      data-aos="fade-up"
      data-aos-delay="200"
    >
      <div className="absolute inset-0">
        <img
          src={image}
          alt={title}
          className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-110"
        />
        <div className="absolute inset-0 bg-black/60 backdrop-blur-sm" />
      </div>
      
      <div className="relative p-8 h-full flex flex-col items-center text-center">
        <div className="mb-6 p-4 bg-gold/10 rounded-full ring-2 ring-gold/30 transform group-hover:scale-110 transition-transform duration-300">
          {icon}
        </div>
        
        <h3 className="text-2xl font-bold text-white mb-4">{title}</h3>
        <p className="text-white/80">{description}</p>
        
        <div className="mt-8">
          <button className="px-6 py-2 bg-gold text-black rounded-lg font-semibold transform hover:scale-105 transition-all duration-300">
            Learn More
          </button>
        </div>
      </div>
    </div>
  );
}