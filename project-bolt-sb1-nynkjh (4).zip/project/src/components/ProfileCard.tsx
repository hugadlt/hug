import React from 'react';
import { Plane, Crown, Car, Instagram, MessageCircle, BadgeCheck, MapPin } from 'lucide-react';
import CountUp from './CountUp';

interface Flight {
  from: string;
  to: string;
  date: string;
  class: 'business' | 'first';
}

interface ProfileCardProps {
  instagramHandle: string;
  profileImage: string;
  businessFlights: number;
  firstClassFlights: number;
  maybachTransfers: number;
  flightHistory: Flight[];
}

export default function ProfileCard({
  instagramHandle,
  profileImage,
  businessFlights,
  firstClassFlights,
  maybachTransfers,
  flightHistory,
}: ProfileCardProps) {
  const whatsappNumber = "+33620272526";
  const whatsappMessage = encodeURIComponent("Hello, I'm interested in your luxury concierge services.");

  return (
    <>
      <div className="relative bg-white/5 backdrop-blur-lg rounded-2xl p-8 border border-gold/20 shadow-2xl" data-aos="fade-up" data-aos-duration="1000">
        <div className="absolute inset-0 bg-gradient-to-br from-dark/90 to-transparent rounded-2xl z-0" />
        <div className="relative z-10">
          <div className="flex items-center gap-6" data-aos="fade-right" data-aos-delay="200">
            <div className="relative group">
              <div className="w-24 h-24 rounded-full overflow-hidden ring-4 ring-gold/50 group-hover:ring-gold transition-all duration-300">
                <img
                  src={profileImage}
                  alt="Profile"
                  className="w-full h-full object-cover"
                />
              </div>
              <div className="absolute -bottom-2 -right-2 bg-blue-500 p-2 rounded-full transform hover:scale-110 transition-transform duration-300">
                <BadgeCheck className="w-4 h-4 text-white" />
              </div>
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h2 className="text-2xl font-bold text-white">@{instagramHandle}</h2>
                <Instagram className="w-5 h-5 text-pink-500" />
                <Crown className="w-5 h-5 text-gold animate-pulse-slow" />
              </div>
              <p className="text-gold/80 font-light">Elite Member</p>
            </div>
          </div>

          <div className="mt-8 flex flex-col gap-4">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <StatCard
                icon={<Crown className="w-6 h-6" />}
                label="First Class Experience"
                value={firstClassFlights}
                delay={600}
              />
              <StatCard
                icon={<Plane className="w-6 h-6 transform -rotate-45" />}
                label="Business Class Flights"
                value={businessFlights}
                delay={800}
              />
              <StatCard
                icon={<Car className="w-6 h-6" />}
                label="VIP Transfers"
                value={maybachTransfers}
                delay={1000}
              />
            </div>
          </div>

          <div className="mt-12">
            <h3 className="text-lg font-semibold text-white mb-6">Flight History</h3>
            <div className="space-y-12">
              {flightHistory.map((flight, index) => (
                <div 
                  key={index} 
                  className="relative bg-black/40 p-6 rounded-xl border border-gold/20 transform hover:scale-[1.02] transition-all duration-300"
                  data-aos="fade-up"
                  data-aos-delay={200 * (index + 1)}
                >
                  <div className="flex items-center justify-between mt-4">
                    <div className="flex items-center gap-2">
                      <MapPin className="w-4 h-4 text-gold" />
                      <span className="text-white font-medium">{flight.from}</span>
                    </div>
                    <div className="flex-1 px-4 relative">
                      <div className="h-[2px] bg-gradient-to-r from-gold via-gold to-gold" />
                      <div className="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2">
                        <div className="relative">
                          <div className="absolute inset-0 bg-gold/20 rounded-full animate-ping" />
                          <Plane className="w-5 h-5 text-gold transform -rotate-45" />
                        </div>
                      </div>
                    </div>
                    <div className="flex items-center gap-2">
                      <span className="text-white font-medium">{flight.to}</span>
                      <MapPin className="w-4 h-4 text-gold" />
                    </div>
                  </div>
                  <div className="mt-4 text-sm text-gold/80 text-center font-medium">
                    {flight.date} • {flight.class} Class
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>

      <a
        href={`https://wa.me/${whatsappNumber}?text=${whatsappMessage}`}
        target="_blank"
        rel="noopener noreferrer"
        className="mt-8 flex items-center justify-center gap-2 w-full bg-gradient-to-r from-emerald-500 to-emerald-600 hover:from-emerald-600 hover:to-emerald-700 text-white py-4 rounded-xl font-medium transition-all duration-300 shadow-lg hover:shadow-xl transform hover:scale-[1.02]"
      >
        <MessageCircle className="w-5 h-5" />
        Contact Your Personal Concierge
      </a>
    </>
  );
}

function StatCard({ icon, label, value, delay }: { icon: React.ReactNode; label: string; value: number; delay: number }) {
  return (
    <div 
      data-aos="fade-up" 
      data-aos-delay={delay}
      className="bg-black/30 rounded-xl p-6 border border-white/10 hover:border-gold/50 transition-all duration-300 transform hover:scale-[1.02]"
    >
      <div className="flex items-center gap-4">
        <div className="text-gold">{icon}</div>
        <div>
          <div className="text-2xl font-bold text-white">
            <CountUp end={value} />
          </div>
          <div className="text-sm text-white/60">{label}</div>
        </div>
      </div>
    </div>
  );
}