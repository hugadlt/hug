import React from 'react';

export default function POAPBadge() {
  return (
    <div className="relative w-56 h-56" data-aos="zoom-in" data-aos-duration="1500">
      <div className="absolute inset-0 bg-gradient-to-r from-gold via-amber-400 to-gold rounded-full animate-spin-slow opacity-50 blur-lg" />
      <div className="relative w-full h-full rounded-full overflow-hidden ring-4 ring-gold/50 transform hover:scale-105 transition-transform duration-300">
        <img
          src="https://images.unsplash.com/photo-1540962351504-03099e0a754b?auto=format&fit=crop&q=80&w=400&h=400"
          alt="POAP Badge"
          className="w-full h-full object-cover"
        />
      </div>
    </div>
  );
}